"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const promise_1 = __importDefault(require("mysql2/promise"));
const connectionConfig = {
    host: process.env.RDS_HOST,
    user: process.env.RDS_USER,
    password: process.env.RDS_PASSWORD,
    database: process.env.RDS_DATABASE,
};
const handler = async (event) => {
    const connection = await promise_1.default.createConnection(connectionConfig);
    try {
        for (const record of event.Records) {
            if (record.eventName === 'INSERT' && record.dynamodb?.NewImage) {
                const newImage = record.dynamodb.NewImage;
                const transaction = {
                    id: newImage.id.S,
                    userId: newImage.userId.S,
                    amount: parseFloat(newImage.amount.N),
                    description: newImage.description.S,
                    createdAt: newImage.createdAt.S,
                };
                await connection.execute('INSERT INTO transactions (id, user_id, amount, description, created_at) VALUES (?, ?, ?, ?, ?)', [
                    transaction.id,
                    transaction.userId,
                    transaction.amount,
                    transaction.description,
                    transaction.createdAt,
                ]);
                console.log('Inserted transaction into RDS:', transaction);
            }
        }
    }
    catch (error) {
        console.error('Error inserting into RDS:', error);
        throw error;
    }
    finally {
        await connection.end();
    }
};
exports.handler = handler;
